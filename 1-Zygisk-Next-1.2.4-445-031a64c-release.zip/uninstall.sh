rm -rf /data/adb/zygisksu 2>/dev/null
rm -rf /data/adb/modules/zn_magisk_compat 2>/dev/null
rm /data/adb/service.d/.zn_cleanup.sh 2>/dev/null
rm /data/adb/ksu/bin/znctl 2>/dev/null
rm /data/adb/ap/bin/znctl 2>/dev/null
